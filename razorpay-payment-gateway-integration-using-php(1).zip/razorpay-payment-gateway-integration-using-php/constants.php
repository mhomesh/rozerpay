<?php
// credential
define('RAZOR_KEY_ID', 'XXXXXXXXXXXXXXXX');
define('RAZOR_KEY_SECRET', 'XXXXXXXXXXXXXXXX');

?>
